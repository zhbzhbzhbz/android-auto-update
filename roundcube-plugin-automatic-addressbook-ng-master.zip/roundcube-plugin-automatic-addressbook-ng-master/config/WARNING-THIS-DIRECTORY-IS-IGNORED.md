# WARNING - This directory is ignored



This config/ directory is entirely ignored by this plugin.



Its sole purpose of existence is to serve as a visible clue and a reference
point for enumerating available configuration settings.

Actual default configuration values are stored as properties in main plugin
class (which has the same name as plugin itself).
