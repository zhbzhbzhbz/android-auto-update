var skinColorDefault = "6da1d3";
        
var skinColorValues = [
    // dark,   darker,   darkest,  light,    lighter,  lightest
    ["6da1d3", "1F75CC", "166ac0", "BFD9F2", "D3E8FF", "E9F4FF"],
    ["6dcfd3", "1fbecc", "16aac0", "bfeef2", "d3f9ff", "e9fcff"],
    ["6dd374", "1fcc2b", "2fae50", "bff2c3", "d3ffd5", "e9ffec"],
    ["b76dd3", "a51fcc", "9900cc", "e4bff2", "edd3ff", "fae9ff"],
    ["d3bc6d", "cca51f", "c09616", "f2e4bf", "fff5d3", "fffae9"],
    ["ce7070", "970000", "cc1f1f", "f8d7d7", "ffd3d3", "feefef"]
];

var skinColorStyles = 

    /* color 1 - dark */

    ".color-%1 input.button.mainaction:active"+    
    "{ background-color: #%1; }" +
    
    ".color-%1 .records-table td span:before,"+
    ".color-%1 .records-table th span:before,"+
    ".color-%1 .records-table th a:before,"+
    ".color-%1 .records-table thead td div:before,"+
    ".color-%1 .records-table thead th div:before,"+
    ".color-%1 .records-table thead td a:after,"+
    ".color-%1 .records-table thead th a:after,"+
    ".color-%1 .records-table div.expanded,"+
    ".color-%1 .records-table div.collapsed,"+
    ".color-%1 .boxfooter .listbutton.groupactions:before,"+
    ".color-%1 #rss a,"+
    ".color-%1 a.iconbutton:before,"+
    ".color-%1 .minmodetoggle:before,"+
    ".color-%1 #mailpreviewtoggle,"+
    ".color-%1 .toolbar a.button:before," +
    ".color-%1 .boxfooter .listbutton.groupactions,"+
    ".color-%1 .boxfooter .listbutton.add,"+
    ".color-%1 .boxfooter .listbutton.delete,"+
    ".color-%1 .boxfooter .listbutton.removegroup,"+ 
    ".color-%1 .boxfooter .listbutton.addto .inner,"+
    ".color-%1 .boxfooter .listbutton.addcc .inner,"+
    ".color-%1 .boxfooter .listbutton.addbcc .inner,"+
    ".color-%1 .boxfooter .countdisplay"+
    "{ color: #%1; }" +              

    ".color-%1 input[type=button]," +
    ".color-%1 input[type=button]:hover," +
    ".color-%1 fieldset," +
    ".color-%1 a.menuselector," +
    ".color-%1 #topnav," +
    ".color-%1 .minimal #topnav," +
    ".color-%1 #taskbar a.button-selected," +
    ".color-%1 .popupmenu," +
    ".color-%1 #messagestack div," +
    ".color-%1 #maillistmode.selected,"+
    ".color-%1 #mailthreadmode.selected,"+
    ".color-%1 #rcmKSearchpane," +
    ".rcs-desktop.color-%1 select" +
    "{ border-color: #%1; }" +

    ".rcs-desktop.color-%1 input[type=text]," +
    ".rcs-desktop.color-%1 input[type=password]," +
    ".rcs-desktop.color-%1 input[type=email]," +
    ".rcs-desktop.color-%1 textarea" +            
    "{ border-color: #%1 !important; }" +               
    
    /* color 2 - darker */

    ".color-%1 body.mailbox #inboxButton a" +
    "{ background-color: #%2; }" +    

    ".color-%1 .records-table thead tr .status span.status,"+
    ".color-%1 .records-table thead tr .flag span.flagged,"+
    ".color-%1 .records-table thead tr .attachment span.attachment,"+
    ".color-%1 .records-table thead tr .priority span.priority,"+
    ".color-%1 .records-table thead td a,"+
    ".color-%1 .records-table thead th a"+
    "{ color: #%2 !important; }" +    
    
    /* color 3 - darkest */

    ".color-%1 input.button,"+
    ".color-%1 .formbuttons input.button,"+
    ".color-%1 input.button.mainaction,"+
    ".color-%1 #login-form input.button,"+
    ".color-%1 #topline a," +
    ".color-%1 .username select.deco," +
    ".color-%1 #taskbar a span.button-inner," +
    ".color-%1 .toolbar a.button," +
    ".color-%1 a," +
    ".color-%1 #topline,"+
    ".color-%1 .minimal #topline,"+
    ".color-%1 #main-menu a.active,"+
    ".color-%1 #taskbar a.button-calendar span.button-inner,"+ 
    ".color-%1 #taskbar a.button-calendar.button-selected span.button-inner," +
    ".color-%1 ul#planner_controls li a"+
    "{ color: #%3; }" +            
    
    /* color 4 - light */
    
    ".color-%1 .uibox," +
    ".color-%1 #compose-content,"+
    ".color-%1 #mailview-top,"+
    ".color-%1 #mailview-bottom,"+
    ".color-%1 #messagebody p.image-attachment,"+
    ".color-%1 .records-table.fixedheader,"+
    ".color-%1 #messagelistfooter,"+
    ".color-%1 .moreheaderstoggle,"+
    ".color-%1 #messageheader,"+
    ".color-%1 #composeheaders,"+
    ".color-%1 #composeoptions,"+
    ".color-%1 #compose-attachments,"+
    ".color-%1 #compose-contacts #directorylist,"+
    ".color-%1 .listbox .boxfooter,"+    
    ".color-%1 #taskbar a,"+
    ".color-%1 .minimal #taskbar a,"+
    ".color-%1 ul#planner_controls li a,"+
    ".color-%1 .boxtitle, .uibox .listing thead td,"+
    ".color-%1 .boxtitle, .uibox .listing thead th,"+
    ".color-%1.iframe h1.boxtitle"+
    "{ border-color: #%4; }" +   
    
    /* color 5 - lighter */
    
    ".color-%1 .listbox .listitem.selected,"+ 
    ".color-%1 .listbox .tablink.selected,"+
    ".color-%1 .listbox .listitem.selected > a,"+ 
    ".color-%1 .listbox .tablink.selected > a,"+ 
    ".color-%1 .listing tbody tr.unfocused td,"+ 
    ".color-%1 .listing tbody tr.selected td,"+ 
    ".color-%1 .listing li.selected,"+ 
    ".color-%1 .listing li.selected > a," +
    ".color-%1 #mailboxlist li.mailbox .unreadcount,"+
    ".rcs-desktop.color-%1 #composeoptionstoggle"+
    "{ background-color: #%5; }" +            
    
    ".color-%1 .records-table tr.selected td,"+
    ".color-%1 .records-table tr.unfocused td,"+
    ".color-%1 input[type=button]:hover," +
    ".color-%1 .formbuttons input.button:active,"+
    ".color-%1 a.rowLink:hover," +
    ".color-%1 #remote-objects-message a:hover"+
    "{ background-color: #%5 !important; }" +
    
    
    ".color-%1 #mailboxlist li.mailbox ul,"+
    ".color-%1 .listbox .listitem," +
    ".color-%1 .listbox .tablink," +
    ".color-%1 .listing tbody td," +
    ".color-%1 .listing li"+    
    "{ border-color: #%5; }" +
    
    /* color 6 - lightest */
    
    ".color-%1 #composeheaders,"+
    ".color-%1 #taskbar a,"+
    ".color-%1 .minimal #taskbar a,"+    
    ".color-%1 .moreheaderstoggle,"+
    ".color-%1 .records-table thead td," +
    ".color-%1 .records-table thead th," +
    ".color-%1 input[type=button]," +
    ".color-%1 .uibox .listing thead td,"+
    ".color-%1 .uibox .listing thead th,"+
    ".color-%1 .uibox .boxtitle,"+ 
    ".color-%1 .listbox," +
    ".color-%1 ul.listing li," +
    ".color-%1 ul#planner_controls li a,"+
    ".color-%1 #messagelistfooter,"+
    ".color-%1.iframe h1.boxtitle"+
    "{ background-color: #%6; }"+

    ".color-%1 .popupmenu a:hover"+
    "{ background-color: #%6 !important; }";
