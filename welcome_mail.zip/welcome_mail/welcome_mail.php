<?php
/*
* Let a newly created user receive a welcome mail after first-logon.
* @author Zhouhongbo
* Roundcube Plugin API: https://github.com/roundcube/roundcubemail/wiki/Plugin-API
* Roundcube Plugin Hook: https://github.com/roundcube/roundcubemail/wiki/Plugin-Hooks#task-login
* User-create Event sample: https://github.com/roundcube/roundcubemail/blob/master/plugins/squirrelmail_usercopy/squirrelmail_usercopy.php 
*/
require 'class.phpmailer.php';
class welcome_mail extends rcube_plugin
{
    public $task = 'login';
	private $from = 'admin@pkumun.org.cn'; //发件人地址
	private $pw = "";
	private $subject = '欢迎使用北大模联协会企业邮箱！'; //主题
	private $body = '亲爱的北大模联人,\r\n    您好！欢迎使用北京大学模拟联合国协会的企业邮箱系统！\r\n    在使用前请查看附件中的使用教程\r\n    在使用中若有问题，欢迎发邮件至admin@pkumun.org.cn进行询问'; //内容
	function init()
    {
        $this->add_hook('user_create', array($this, 'send_mail_after_first_logon'));
    }
	
	function send_mail_after_first_logon($args){
		$user_email = $args['user'];//切记，这里不能用user_email和user_name，是空的
		$mail = new PHPMailer;
		// Set PHPMailer to use the sendmail transport
		$mail->isSendmail();
		
		//如果用本地的smtp服务器发给本地的邮箱，这部分不需要
		//$mail->SMTPAuth = true; // enable SMTP authentication
		//$mail->SMTPSecure = "ssl"; // sets the prefix to the servier
		//$mail->Host = smtp.mailserver.com";
		//$mail->Port = "587";
		//$mail->Username = $this->from;
		//$mail->Password = $this->pw;
		
		$mail->setFrom($this->from, 'Admin');
		$mail->addReplyTo($this->from, 'Admin');
		$mail->addAddress($user_email, "Dear PKUMUNer");
		$mail->Subject = $this->subject;
		//$mail->IsHTML(true);  // send as HTML
		$mail->Body = $this->body;
		$mail->AddAttachment("README_EN.pdf"); // attachment
		$mail->AddAttachment("使用教程_CN.pdf"); // attachment
		
		if (!$mail->send()) {
			error_log("Mailer Error: " . $mail->ErrorInfo);
		}
		return $args;
	}
}
?>